Ryann1908's MKII shot sheet (v1.0)

This is a bullet-only shot sheet originally designed for and tested in LuaSTG aex+ v0.8.21-beta (based on LuaSTGExPlus v0.83b), however, it can be used in other engines.

All bullets are of at least 1080p equivalent size (2.25x the size of the original ones, some reaching nearly 13x).

Terms of use: shot sheet images are free to use in personal/non-commercial projects. For commercial projects, contact me first.

"bullet.lua" not originally by me, but from THlib. This copy is a modified version to support this shot sheet.
If you're using the shot sheet in another engine, I've also included a copy of each file with the appropriate image rects.

Contact:
Discord - @ryann1908
Twitter - @RyannThi